Full name: Marwa Arghandiwal
Student ID: 2451932
Chapman email: arghandiwal@chapman.edu
Course number and section: CPSC 350 - 03
Assignment or exercise number: PA3-Do you See What I see?

Source Files: 
- Main.cpp
- MonoStack.h
- SpeakerView.h
- input.txt

Errors: N/A

References: used claude.ai to help debug minor run Errors

To run: g++ Main.cpp -o e.exe
./e.exe input.txt